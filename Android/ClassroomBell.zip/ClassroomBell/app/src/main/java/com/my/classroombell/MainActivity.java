package com.my.classroombell;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.PathParser;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    private static final String PRIMARY_CHANNEL_ID = "primary_notification_channel";
    private NotificationManager mNotificationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Notification
        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        ToggleButton alarmToggle = findViewById(R.id.alarmToggle);
        // Alarm list data
        int[] intArray_h = new int[]{ 8, 8, 8, 9, 9,10,10,11,11,12,13,14,14,15,15,16,16,16,17,17,17,18,19,20,20,20,21,21};
        int[] intArray_m = new int[]{ 0,45,50,35,50,35,40,25,30,15,30,15,20, 5,20, 5,10,55, 5,50,55,40,20, 5,10,55, 0,45};
        int alarm_list_length = intArray_h.length;
        long[] target_time_list = new long[alarm_list_length];
        for (int i=0; i < alarm_list_length; i++) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(System.currentTimeMillis());
            calendar.set(Calendar.HOUR_OF_DAY, intArray_h[i]);
            calendar.set(Calendar.MINUTE, intArray_m[i]);
            calendar.set(Calendar.SECOND, 1);
            long target_time = calendar.getTimeInMillis() - (calendar.getTimeInMillis() % 60000);
            if (System.currentTimeMillis() > target_time) {
                target_time = target_time + (24 * 60 * 60 * 1000);
            }
            target_time_list[i] = target_time;
        }
        long repeatInterval = AlarmManager.INTERVAL_DAY;
        // Toggle status
        Intent Intent_temp = new Intent(this, AlarmReceiver.class);
        boolean alarmUp = (PendingIntent.getBroadcast(
                this, 0, Intent_temp, PendingIntent.FLAG_NO_CREATE) != null);
        alarmToggle.setChecked(alarmUp);
        // PendingIntent
        List<PendingIntent> pi_array = Arrays.asList(new PendingIntent[alarm_list_length]);
        // Alarm manager
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        // Toggle functions
        alarmToggle.setOnCheckedChangeListener(
                new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                        String toastMessage;
                        if (isChecked) {
                            toastMessage = "Classroom bell is now ON";
                            if (alarmManager != null) {
                                for (int i=0; i < alarm_list_length; i++) {
                                    Calendar calendar = Calendar.getInstance();
                                    calendar.setTimeInMillis(System.currentTimeMillis());
                                    calendar.set(Calendar.HOUR_OF_DAY, intArray_h[i]);
                                    calendar.set(Calendar.MINUTE, intArray_m[i]);
                                    calendar.set(Calendar.SECOND, 1);
                                    long target_time = calendar.getTimeInMillis() - (calendar.getTimeInMillis() % 60000);
                                    if (System.currentTimeMillis() > target_time) {
                                        target_time = target_time + (24 * 60 * 60 * 1000);
                                    }
                                    target_time_list[i] = target_time;
                                }
                                for (int i=0; i < alarm_list_length; i++){
                                    Intent Intent = new Intent(MainActivity.this, AlarmReceiver.class);
                                    PendingIntent pi = PendingIntent.getBroadcast
                                            (MainActivity.this, i, Intent, PendingIntent.FLAG_CANCEL_CURRENT);
                                    pi_array.set(i, pi);
                                    alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
                                            target_time_list[i], repeatInterval, pi);
                                }
                            }
                        } else {
                            toastMessage = "Classroom bell is now OFF";
                            mNotificationManager.cancelAll();
                            if (alarmManager != null) {
                                for (int i=0; i < alarm_list_length; i++){
                                    Intent Intent = new Intent(MainActivity.this, AlarmReceiver.class);
                                    PendingIntent pi = PendingIntent.getBroadcast
                                            (MainActivity.this, i, Intent, PendingIntent.FLAG_NO_CREATE);
                                    pi_array.set(i, pi);
                                    pi.cancel();
                                    alarmManager.cancel(pi_array.get(i));
                                }
                            }
                        }
                        // Show a toast to say the alarm is turned on or off.
                        Toast.makeText(MainActivity.this, toastMessage,Toast.LENGTH_SHORT).show();
                    }
                }
        );

        createNotificationChannel();
    }

    public void showToast(View view) {
        Toast toast = Toast.makeText(this, R.string.toast_message, Toast.LENGTH_SHORT);
        toast.show();
    }

    public void createNotificationChannel() {
        // Create a notification manager object.
        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        // Notification channels are only available in OREO and higher.
        // So, add a check on SDK version.
        if (android.os.Build.VERSION.SDK_INT >=
                android.os.Build.VERSION_CODES.O) {
            // Create the NotificationChannel with all the parameters.
            NotificationChannel notificationChannel = new NotificationChannel(
                    PRIMARY_CHANNEL_ID, "ClassroomBell notification",
                    NotificationManager.IMPORTANCE_LOW);
            notificationChannel.enableLights(false);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.enableVibration(true);
            notificationChannel.setDescription("ClassroomBell throughout the day.");
            mNotificationManager.createNotificationChannel(notificationChannel);
        }
    }
}
